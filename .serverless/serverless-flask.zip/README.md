# quarantinenotes
Notes from people on quarantine around the globe.
