-----------------------
# README
-----------------------
VueMail Dark - Email Client is a Vue.js framework based mail Client template


Template Info:
-----------------------
Name: 		Vue-Mail - Vue.js email client dashboard
Version: 	1.0
Author: 	ThemeSINE
Website: 	https://www.themesine.com/


Changelog:
-----------------------
Version 1.0 15-03-2019
- initial release 


Credits:
-----------------------

//=== Frame Work ===== //

1. Vue                                  :	https://vuejs.org/
2. Vuex     		        	: 	https://vuex.vuejs.org/
3. Vuetify				:                 https://vuetifyjs.com/en/
4. Vue Router				:	https://router.vuejs.org/
5. Vue Meta	                  	:	https://www.npmjs.com/package/vue-meta
6. Vue Analytics                        :	https://github.com/MatteoGabriele/vue-analytics

//===Font===== //

7. Webfont - Material Design Icons   	: 	https://materialdesignicons.com/
8. Feather			        : 	https://feathericons.com/
9. Flat Icon    		        : 	https://www.flaticon.com/
10. Google Fonts(Poppins) 	        :	https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900

	


License:
-----------------------
This template is under Free templates License - https://www.themesine.com/license/


															