<template>
  <div class="starred">
    <v-layout row wrap>
      <v-flex xs12>
          <h2>Starred Pages</h2>
      </v-flex>
    </v-layout>
  </div>
</template>

<script>
  export default {
    computed : {
      //
    }
  }
</script>

