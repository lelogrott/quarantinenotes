<template>
  <div class="chat">
    <v-container grid-list-md>
      <v-layout row wrap>
        <v-flex xs12>
          <h2>Chat</h2>
        </v-flex>
      </v-layout>
    </v-container>
  </div>
</template>



<script>
  export default {
    data () {
      return {

      }
    }
  }
</script>

