<template>
  <div class="trash">
    <h2>Trash</h2>
  </div>
</template>

