<template>
  <div class="spam">
    <h2>Spam</h2>
  </div>
</template>

