<template>
  <v-container grid-list-sm>
    <v-layout row wrap>
      <v-flex sm6 xs12>
        <h2>Draft</h2>
      </v-flex>
    </v-layout>
  </v-container>
</template>



