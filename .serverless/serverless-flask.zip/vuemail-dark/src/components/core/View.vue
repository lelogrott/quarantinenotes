<template>
  <v-content>
    <v-container fluid>

      <transition mode="out-in">
        <router-view/>
      </transition>
      
    </v-container>
  </v-content>
</template>

