import { RepositoryFactory } from './repositoryFactory'

export default RepositoryFactory
