export default {
  namespaced: true,
  state: {
    notesInfo: [
      {
        author: "lelogrott",
        content: "fourth update. still working on this",
        country: "BR",
        createdAt: "Sun, 23 Mar 2020 02:31:31 +0000",
        noteId: "83fb02bbb5f84c22a4f3eba048cbdfac"
      },
      {
        author: "lelogrott",
        content: "third update. still working on this",
        country: "US",
        createdAt: "Sun, 22 Mar 2020 03:33:14 +0000",
        noteId: "f14e72b94e8343bd95cb01c9bc72d7ae"
      },
      {
        author: "lelogrott",
        content: "second update. still working on this",
        country: "BR",
        createdAt: "Sun, 22 Mar 2020 02:33:43 +0000",
        noteId: "6b773c7e07dc4f32b78acab8d7e94a41"
      },
      {
        author: "lelogrott",
        content: "first update. still working on this",
        country: "BR",
        createdAt: "Sun, 22 Mar 2020 02:31:31 +0000",
        noteId: "83fb02bbb4f84c22a4f3eba048cbdfac"
      }
    ]
  }
}
