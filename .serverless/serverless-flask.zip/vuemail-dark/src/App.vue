<template>
  <v-app >

    <core-drawer />

    <core-view />

  </v-app>

</template>

<style lang="scss">

  @import "@/styles/index.scss";

</style>
